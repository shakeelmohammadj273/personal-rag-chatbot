# Technical Skills – Mohammad Shakeel

## Programming Languages

* Python
* R
* SQL
* Basic programming and scripting
* Object-oriented programming concepts
* Data structures and algorithms fundamentals

## Artificial Intelligence & Machine Learning

* Artificial Intelligence (AI)
* Machine Learning (ML)
* Supervised Learning
* Unsupervised Learning
* Classification
* Regression
* Model Training
* Model Evaluation
* Feature Engineering
* Data Preprocessing
* Model Fine-tuning
* Machine Learning workflows
* Predictive analytics

## Deep Learning

* Deep Learning fundamentals
* Neural Networks
* Computer Vision
* Object Detection
* Image Classification
* Real-time AI applications
* YOLO
* OpenCV

## Generative AI & LLM

* Large Language Models (LLMs)
* Generative AI
* Retrieval-Augmented Generation (RAG)
* Prompt Engineering
* Embeddings
* Vector Databases
* Semantic Search
* Knowledge-base chatbots
* LLM-based question answering
* Local LLM deployment
* Ollama
* RAG pipeline development
* Context-based response generation

## AI Agents & Frameworks

* LangGraph
* Agentic AI concepts
* AI agent workflows
* Multi-step AI workflows
* Tool-based AI agents
* MCP (Model Context Protocol)
* MCP-based tool integration
* AI workflow orchestration

## AWS / Cloud

* Amazon Web Services (AWS)
* AWS SageMaker
* SageMaker model training
* SageMaker deployment concepts
* SageMaker inference
* Amazon S3
* S3 Buckets
* Cloud-based machine learning workflows
* AWS-based AI/ML solutions
* Model and dataset management using cloud storage

## Computer Vision

* OpenCV
* YOLO
* Object Detection
* Image Processing
* Video Processing
* Real-time Camera Processing
* CCTV/IP Camera Integration
* AI Camera Systems
* PPE Detection
* Vehicle/Truck Speed Monitoring
* OCR-based computer vision applications

## OCR & Document AI

* Optical Character Recognition (OCR)
* PaddleOCR
* OCR preprocessing
* Image enhancement
* Document image processing
* Invoice data extraction
* Text detection and recognition
* OCR confidence-based processing
* PDF-to-image processing
* Structured data extraction

## Python AI/Backend Development

* FastAPI
* REST APIs
* Python backend development
* API integration
* JSON processing
* Authentication concepts
* Backend service development
* AI model API integration

## Docker & Deployment

* Docker
* Docker images
* Docker containers
* Docker Compose
* Containerized AI applications
* Model deployment using Docker
* Application deployment
* Environment configuration

## Databases & Vector Search

* ChromaDB
* Vector databases
* Embeddings
* Semantic similarity search
* SQLite
* Database integration
* Vector-based document retrieval

## AI/RAG Development Tools

* Sentence Transformers
* Hugging Face models
* LangChain concepts
* LangGraph
* Ollama
* ChromaDB
* Python
* FastAPI
* Vector embeddings
* Document chunking
* Semantic retrieval

## Development & Engineering

* Git
* GitHub
* REST API development
* API testing
* Swagger/OpenAPI
* Linux/Ubuntu
* Windows
* Virtual environments
* Environment configuration
* Debugging and troubleshooting

## Automation

* Python automation
* Workflow automation
* AI-based automation
* Process automation
* API-based automation
* Real-time event processing
* Automated alerts and monitoring

## Current AI Learning Areas

* Retrieval-Augmented Generation (RAG)
* Large Language Models (LLMs)
* Agentic AI
* LangGraph
* MCP
* AI agents
* Vector databases
* Semantic search
* Prompt engineering
* Modern AI application development
