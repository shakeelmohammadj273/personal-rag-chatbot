Certifications & Training

- Python
- Machine Learning
- Artificial Intelligence
- AWS
- RAG