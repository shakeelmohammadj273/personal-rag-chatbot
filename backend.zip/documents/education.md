# Education Background

## Bachelor’s Degree in Artificial Intelligence and Data Science

I completed my Bachelor’s degree in **Artificial Intelligence and Data Science** from **SRM Valliammai Engineering College, Kattankulathur, Chennai**.

During my undergraduate studies, I developed a strong foundation in **Artificial Intelligence, Machine Learning, Data Science, and programming**. My academic journey introduced me to both the theoretical concepts and practical applications of AI and machine learning.

### Programming Knowledge

As part of my education, I learned and worked with:

* **Python** – used for programming, data processing, machine learning, and AI development.
* **R Programming** – learned for statistical analysis, data processing, and data science applications.

Python became particularly important in my learning journey because of its extensive ecosystem for Artificial Intelligence and Machine Learning.

### Machine Learning

I studied the fundamental concepts of **Machine Learning**, including:

* Supervised Learning
* Unsupervised Learning
* Classification
* Regression
* Data preprocessing
* Feature engineering
* Model evaluation
* Training and testing datasets
* Basic model optimization
* Understanding model performance

I gained an understanding of how machine learning models are trained using data and how different approaches can be selected depending on the problem.

### Model Training and Fine-Tuning

During my studies, I learned the **basic concepts of model training and fine-tuning**.

I developed an understanding of how models learn patterns from training data, how training parameters can affect model performance, and how an existing pre-trained model can be adapted or fine-tuned for a specific task.

My academic learning provided me with the foundation to understand the complete machine learning workflow, from preparing data to training, evaluating, and improving models.

### Large Language Models and Generative AI

I also developed an introductory understanding of **Large Language Models (LLMs)** and modern Generative AI concepts.

I learned the basic concepts behind:

* Large Language Models
* Generative AI
* Prompt-based interaction
* Pre-trained models
* Model fine-tuning
* Context-based question answering

This academic exposure helped me understand how modern AI systems can process natural language and generate meaningful responses.

### RAG Architecture

I also learned the fundamental concepts of **Retrieval-Augmented Generation (RAG)** architecture.

My understanding includes the basic RAG workflow:

```text
User Question
      ↓
Query Processing
      ↓
Document Retrieval
      ↓
Relevant Information
      ↓
LLM
      ↓
Generated Answer
```

I learned that RAG systems combine **information retrieval with Large Language Models** so that an AI system can retrieve relevant information from an external knowledge source and use that information to generate a response.

### Overall Learning

My education in Artificial Intelligence and Data Science gave me a foundation across **Python programming, R programming, Machine Learning, Artificial Intelligence, model training, basic fine-tuning concepts, LLMs, Generative AI, and RAG architecture**.

This academic foundation became the starting point for my continued practical learning and development in **AI, Machine Learning, Computer Vision, Python, OCR, and modern AI applications**.
