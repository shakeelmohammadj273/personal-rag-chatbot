# EXL Solutions

## Position

Automation Engineer

## Duration

February 2026 – Present

## Company Overview

EXL Solutions develops automation and AI-based industrial solutions for terminal operations, logistics, and safety monitoring.

## Responsibilities

My responsibilities include developing, training, deploying, and maintaining AI models used for real-time industrial safety applications.

My daily work includes:

- Developing Computer Vision models
- Training YOLO models
- Image preprocessing
- OCR
- Docker deployment
- API development
- Camera integration
- Performance optimization
- AI model testing
- Bug fixing

## Major Projects

### PPE Detection System

Developed an AI system that detects workers not wearing mandatory PPE.

The system processes CCTV camera streams and detects:

- Helmet
- Safety Vest
- Person

Whenever a violation occurs, the system generates an alert.

Technologies:

- Python
- YOLO
- OpenCV
- Docker

### Truck Speed Monitoring

Developed an AI-based speed estimation system capable of calculating truck speed inside terminal yards.

The system identifies vehicles, tracks movement across frames, estimates speed, and generates alerts when speed exceeds predefined thresholds.

Technologies:

- Python
- OpenCV
- YOLO

## Deployment

The applications were deployed using Docker containers and integrated with AI cameras and existing CCTV infrastructure.

## Challenges

- Camera angle variations
- Poor lighting
- Weather conditions
- Real-time inference latency

## Solutions

- Dataset augmentation
- Image preprocessing
- Confidence threshold optimization
- Model optimization

## Result

Successfully deployed real-time AI monitoring systems for terminal safety.