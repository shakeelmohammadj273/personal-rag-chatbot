# Mohammad Shakeel

## Introduction

My name is Mohammad Shakeel, and I am an AI Engineer with three years of experience, including two years of professional experience and one year of internship experience in Artificial Intelligence, Machine Learning, Computer Vision, and Python development.

I am currently working as an Automation Engineer at EXL Solutions in Dubai, where I develop AI-powered industrial automation systems for terminal safety and operational efficiency.

My primary expertise includes Python, Computer Vision, Machine Learning, Deep Learning, Docker, FastAPI, OCR, YOLO, OpenCV, and Retrieval-Augmented Generation (RAG).

I enjoy solving real-world industrial problems using Artificial Intelligence and continuously learning new technologies.