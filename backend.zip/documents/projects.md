PPE Detection
Truck Speed Monitoring
Invoice OCR
Container Number Recognition
Container Stacking Prediction
STS Crane Camera Project
Personal RAG Chatbot
AI Camera System