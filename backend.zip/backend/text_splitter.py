from langchain_text_splitters import RecursiveCharacterTextSplitter


def split_documents(documents):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )

    chunks = []

    for doc in documents:
        split_texts = splitter.split_text(doc["text"])

        for i, chunk in enumerate(split_texts):
            chunks.append({
                "text": chunk,
                "source": doc.get(
                    "source",
                    "Unknown"
                ),
                "page": doc.get(
                    "page",
                    0
                ),
                "type": doc.get(
                    "type",
                    "unknown"
                ),
                "chunk_id": i
            })
          

    return chunks