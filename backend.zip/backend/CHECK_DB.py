# from vector_store import VectorStore

# store = VectorStore()

# count = store.collection.count()

# print(f"Total documents in DB: {count}")

from embeddings import model
from vector_store import VectorStore


# -----------------------------------------
# Connect to vector database
# -----------------------------------------

store = VectorStore()

count = store.collection.count()

print("=" * 60)
print("RETRIEVAL ACCURACY TEST")
print("=" * 60)

print(f"Total documents in DB: {count}")


# -----------------------------------------
# Test questions
# -----------------------------------------

questions = [
    "What is your current job?",
    "What are you doing in your current company?",
    "Tell me about your AI experience.",
    "What are your technical skills?",
    "What is your educational background?",
    "Tell me about your projects.",
    "What certifications do you have?",
]


# -----------------------------------------
# Test each question
# -----------------------------------------

for question in questions:

    print("\n" + "=" * 60)
    print(f"QUESTION: {question}")
    print("=" * 60)

    # -----------------------------------------
    # Create query embedding
    # -----------------------------------------

    query_embedding = model.encode(
        question
    ).tolist()

    # -----------------------------------------
    # Search ChromaDB
    # -----------------------------------------

    results = store.search(
        query_embedding=query_embedding,
        n_results=5
    )

    documents = results.get(
        "documents",
        [[]]
    )[0]

    metadatas = results.get(
        "metadatas",
        [[]]
    )[0]

    distances = results.get(
        "distances",
        [[]]
    )[0]

    # -----------------------------------------
    # Display retrieved results
    # -----------------------------------------

    for i, document in enumerate(documents):

        metadata = (
            metadatas[i]
            if i < len(metadatas)
            else {}
        )

        distance = (
            distances[i]
            if i < len(distances)
            else "N/A"
        )

        source = metadata.get(
            "source",
            "Unknown"
        )

        page = metadata.get(
            "page",
            "N/A"
        )

        print("\n" + "-" * 60)

        print(f"RESULT {i + 1}")

        print(f"Source   : {source}")
        print(f"Page     : {page}")
        print(f"Distance : {distance}")

        print("\nContent:")
        print(document)

    print("\n")