import sys
import os

# Add backend folder to Python path
backend_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, backend_path)

from chat import ChatBot

bot = ChatBot()

print("=" * 50)
print("Personal AI Chatbot")
print("Type 'exit' to quit")
print("=" * 50)

while True:

    question = input("\nYou: ")

    if question.lower() == "exit":
        break

    answer = bot.ask(question)

    print("\nAssistant:")
    print(answer)