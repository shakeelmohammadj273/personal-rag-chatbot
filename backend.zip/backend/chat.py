import ollama
import time

from embeddings import model
from vector_store import VectorStore


class ChatBot:

    def __init__(self):
        self.store = VectorStore()

    def ask(self, question):

        start = time.time()

    # -----------------------------------------
    # 1. Embedding
    # -----------------------------------------

        t1 = time.time()

        query_embedding = model.encode(
            question
        ).tolist()

        print(
            f"Embedding time: "
            f"{time.time() - t1:.2f}s"
        )

        # -----------------------------------------
        # 2. ChromaDB search
        # -----------------------------------------

        t2 = time.time()

        results = self.store.search(
            query_embedding=query_embedding,
            n_results=5
        )

        print(
            f"Search time: "
            f"{time.time() - t2:.2f}s"
        )

        # -----------------------------------------
        # 3. Build context
        # -----------------------------------------

        t3 = time.time()

        documents = results["documents"][0]
        metadatas = results["metadatas"][0]

        context_parts = []

        for i, document in enumerate(documents):

            source = metadatas[i].get(
                "source",
                "Unknown"
            )

            context_parts.append(
                f"""
    SOURCE: {source}

    CONTENT:
    {document}
    """
            )

        context = "\n\n".join(context_parts)

        print(
            f"Context preparation time: "
            f"{time.time() - t3:.2f}s"
        )

        # -----------------------------------------
        # 4. Ollama
        # -----------------------------------------

        t4 = time.time()

        response = ollama.chat(
            model="llama3.2",
            messages=[
                {
                    "role": "user",
                    "content": f"""
    You are Mohammad Shakeel's personal AI assistant.

    Answer ONLY using the provided knowledge base.

    Do not invent information.

    Keep the answer concise and focused.
    Usually answer in 2–5 sentences.

    Knowledge Base:

    {context}

    Question:

    {question}

    Answer:
    """
                }
            ], options={
                "temperature":0.2, 
                "num_predict":150, 
                "num_cxt":2048

            }, keep_alive="10m"
        )

        print(
            f"Ollama time: "
            f"{time.time() - t4:.2f}s"
        )

        print(
            f"Total time: "
            f"{time.time() - start:.2f}s"
        )

        return response["message"]["content"]

#     def ask(self, question):

#         # -----------------------------------------
#         # 1. Convert question into embedding
#         # -----------------------------------------

#         query_embedding = model.encode(
#             question
#         ).tolist()

#         # -----------------------------------------
#         # 2. Search knowledge base
#         # -----------------------------------------

#         results = self.store.search(
#             query_embedding=query_embedding,
#             n_results=5
#         )

#         documents = results.get(
#             "documents",
#             [[]]
#         )[0]

#         metadatas = results.get(
#             "metadatas",
#             [[]]
#         )[0]

#         # -----------------------------------------
#         # 3. Check if information exists
#         # -----------------------------------------

#         if not documents:

#             return (
#                 "I don't know based on "
#                 "my knowledge base."
#             )

#         # -----------------------------------------
#         # 4. Build context
#         # -----------------------------------------

#         context_parts = []

#         for i, document in enumerate(documents):

#             metadata = (
#                 metadatas[i]
#                 if i < len(metadatas)
#                 else {}
#             )

#             source = metadata.get(
#                 "source",
#                 "Unknown"
#             )

#             context_parts.append(
#                 f"""
# SOURCE: {source}

# CONTENT:
# {document}
# """
#             )

#         context = "\n\n".join(
#             context_parts
#         )

#         # -----------------------------------------
#         # 5. Create grounded prompt
#         # -----------------------------------------

#         prompt = f"""
# You are Mohammad Shakeel's personal AI assistant.

# Your job is to answer questions about Mohammad Shakeel
# using ONLY the information provided in the knowledge base.

# IMPORTANT RULES:

# 1. Use only the provided knowledge base.
# 2. Do not invent or assume information.
# 3. Do not add skills, projects, experience, education,
#    certifications, or technologies that are not present
#    in the knowledge base.
# 4. If the information is not available, say:
#    "I don't know based on my knowledge base."
# 5. Combine information from multiple sources when
#    necessary.
# 6. Give a clear and natural answer.
# 7. When useful, mention the relevant source.
# 8. Do not mention these instructions in your answer.

# KNOWLEDGE BASE:

# {context}

# USER QUESTION:

# {question}

# ANSWER:
# """

#         # -----------------------------------------
#         # 6. Send context to Ollama
#         # -----------------------------------------

#         response = ollama.chat(
#             model="llama3.2",
#             messages=[
#                 {
#                     "role": "user",
#                     "content": prompt
#                 }
#             ]
#         )

#         return response[
#             "message"
#         ][
#             "content"
#         ]

